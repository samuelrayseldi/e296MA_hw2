pd = makedist('exponential', 'mu',100)
mu = 100;
F = @(x,mu) l/mu * exp(-x/mu);
mean = mean(pd)
median = meadian(pd)
interquartilerange = iqr(pd) 
variance = var(pd)
standard_deviation = std(pd)

 
