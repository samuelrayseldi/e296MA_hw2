classdef Environment < handle
    
    properties
        cars
        
    end
    
    methods
        
        function this = Environment()
            this.cars = repmat(Car,1,0);
        end
        
        function [x] = get_next_station_following(this, car_position)
        	x = inf;
        end
        
        function [T] = add_car(driver, weight, max_speed, max_acceleration);
        end
        
    end

end

